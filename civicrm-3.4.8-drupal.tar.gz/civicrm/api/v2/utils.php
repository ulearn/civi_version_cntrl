<?php

if (!function_exists('_civicrm_initialize')) {
  require_once 'api/v2/utils.v2.php';
}

